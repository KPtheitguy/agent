from agent.core.base import Agent
from agent.core.logger import setup_logfire_logger

if __name__ == "__main__":
    logger = setup_logfire_logger()
    logger.info("Starting agent...")
    agent = Agent()
    agent.run()
