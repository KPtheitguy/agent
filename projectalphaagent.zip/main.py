import threading
import time
from agent.core.websocket_client import main as websocket_main
from agent.core.logger import setup_logger

# Initialize logging
logger = setup_logger()

def start_websocket_client():
    """Starts the WebSocket client."""
    try:
        logger.info("Starting WebSocket client...")
        agent_id = "your-agent-id"  # Replace with actual agent ID or retrieve dynamically
        websocket_main(agent_id)
    except Exception as e:
        logger.error(f"WebSocket client failed to start: {e}")

def monitor_agent_health():
    """Monitor the health of the agent."""
    while True:
        try:
            # Example health monitoring logic
            logger.info("Monitoring agent health...")
            time.sleep(30)  # Adjust the interval as needed
        except Exception as e:
            logger.error(f"Error during agent health monitoring: {e}")

def start_health_monitor():
    """Starts the health monitoring in a separate thread."""
    try:
        health_thread = threading.Thread(target=monitor_agent_health, daemon=True)
        health_thread.start()
    except Exception as e:
        logger.error(f"Failed to start health monitoring: {e}")

if __name__ == "__main__":
    logger.info("Agent starting...")

    # Start WebSocket client
    websocket_thread = threading.Thread(target=start_websocket_client, daemon=True)
    websocket_thread.start()

    # Start health monitoring
    start_health_monitor()

    # Main loop for other agent tasks
    try:
        while True:
            logger.info("Agent running...")
            time.sleep(60)  # Adjust the interval as needed
    except KeyboardInterrupt:
        logger.info("Agent stopping...")
