from agent.core.agent_portal import AgentPortal

if __name__ == "__main__":
    portal = AgentPortal()
    # Example values for demonstration
    portal.register_agent("dummy-token", "dummy-agent")
