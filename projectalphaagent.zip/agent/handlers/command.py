class CommandHandler:
    def execute(self, command):
        print(f"Executing command: {command}")
