from agent.core.metrics import collect_metrics

class MetricsHandler:
    def get_metrics(self):
        return collect_metrics()
