import subprocess

class NginxManager:
    @staticmethod
    def manage(action):
        if action in ["start", "stop", "reload"]:
            subprocess.run(["sudo", "systemctl", action, "nginx"], check=True)
            return f"NGINX {action} successful."
        else:
            return "Invalid action."

    @staticmethod
    def create_site(site_name, config):
        site_path = f"/etc/nginx/sites-available/{site_name}"
        with open(site_path, "w") as f:
            f.write(config)
        subprocess.run(["sudo", "ln", "-s", site_path, f"/etc/nginx/sites-enabled/{site_name}"], check=True)
        NginxManager.manage("reload")
