class RemoteAccess:
    @staticmethod
    def establish_rdp_session(host, username, password):
        return f"Connecting to {host} with user {username} (RDP)..."

    @staticmethod
    def establish_ssh_session(host, username, key):
        return f"Connecting to {host} with user {username} (SSH)..."
