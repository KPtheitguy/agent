from pydantic import BaseModel

class AgentFeatures(BaseModel):
    host_details: bool = True
    live_queries: bool = True
    system_health: bool = True
    software_inventory: bool = True
