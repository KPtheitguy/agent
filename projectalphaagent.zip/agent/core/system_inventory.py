import psutil
import subprocess

class SystemInventory:
    @staticmethod
    def collect():
        return {
            "cpu": psutil.cpu_percent(interval=1),
            "memory": psutil.virtual_memory().percent,
            "disk": psutil.disk_usage("/").percent,
            "apps": SystemInventory.get_installed_apps()
        }

    @staticmethod
    def get_installed_apps():
        try:
            result = subprocess.check_output(["dpkg", "-l"], stderr=subprocess.STDOUT)
            return result.decode().splitlines()[5:]
        except Exception as e:
            return {"error": str(e)}
