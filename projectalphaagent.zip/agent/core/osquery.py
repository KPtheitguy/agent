import subprocess

class OSQuery:
    @staticmethod
    def execute(query):
        try:
            result = subprocess.check_output(["osqueryi", "--json", query])
            return result.decode()
        except Exception as e:
            return {"error": str(e)}
