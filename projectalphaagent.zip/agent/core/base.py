from agent.core.features import AgentFeatures
from agent.core.osquery import OSQuery
from agent.core.nginx import NginxManager
from agent.core.system_inventory import SystemInventory
from agent.core.remote_access import RemoteAccess
from agent.core.agent_portal import AgentPortal

class Agent:
    def __init__(self):
        self.features = AgentFeatures()
        self.portal = AgentPortal()

    def run(self):
        self.portal.register_agent()
        if self.features.host_details:
            print("Collecting system inventory...")
            inventory = SystemInventory.collect()
            print(inventory)
