class BaseAgent:
    def start(self):
        print("Starting the base agent...")
