import logging
import logfire

def setup_logfire_logger():
    return logfire.Logger(service="custom-agent", log_level=logging.DEBUG, api_key="your-logfire-api-key")
