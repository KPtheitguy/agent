import requests
import socket

class AgentPortal:
    API_URL = "https://agentportal.koushik.us/api/v1/agents"

    def __init__(self):
        self.agent_id = None

    def register_agent(self):
        try:
            payload = {
                "registration_token": "your-registration-token",  # Replace with dynamic input or environment variable
                "hostname": socket.gethostname(),
                "ip_address": socket.gethostbyname(socket.gethostname()),
                "agent_name": "example-agent",  # Replace with dynamic input or environment variable
                "version": "1.0.0",
                "heartbeat_interval": 30,
                "log_level": "INFO",
                "config": {
                    "site": "example-site",  # Replace with dynamic input or environment variable
                    "location": "example-location"  # Replace with dynamic input or environment variable
                }
            }
            response = requests.post(f"{self.API_URL}/register", json=payload)
            if response.status_code == 200:
                self.agent_id = response.json().get("id")
                print("Agent registered successfully. Agent ID:", self.agent_id)
            else:
                print(f"Failed to register agent: {response.status_code}, {response.text}")
        except Exception as e:
            print(f"Error during agent registration: {str(e)}")

    def send_heartbeat(self):
        if not self.agent_id:
            print("Agent ID not found. Cannot send heartbeat.")
            return

        try:
            payload = {
                "status": "running",
                "version": "1.0.0",
                "metrics": {
                    "cpu": 20.5,
                    "memory": 50.2,
                    "disk": 30.0
                },
                "system_info": {
                    "os": "Ubuntu 20.04",
                    "kernel": "5.4.0",
                    "hostname": socket.gethostname()
                },
                "error_count": 0
            }
            response = requests.post(f"{self.API_URL}/{self.agent_id}/heartbeat", json=payload)
            if response.status_code == 200:
                print("Heartbeat sent successfully.")
            else:
                print(f"Failed to send heartbeat: {response.status_code}, {response.text}")
        except Exception as e:
            print(f"Error during heartbeat: {str(e)}")
