import socket
import platform

def collect_host_details():
    return {
        "hostname": socket.gethostname(),
        "os_version": platform.platform(),
        "ip_address": socket.gethostbyname(socket.gethostname())
    }
