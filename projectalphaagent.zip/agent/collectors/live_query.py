import subprocess

def execute_osquery(query):
    try:
        result = subprocess.check_output(["osqueryi", query, "--json"], stderr=subprocess.STDOUT)
        return result.decode()
    except Exception as e:
        return {"error": str(e)}
