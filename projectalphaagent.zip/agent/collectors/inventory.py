import subprocess

def collect_software_inventory():
    try:
        result = subprocess.check_output(["dpkg", "--list"], stderr=subprocess.STDOUT)
        return result.decode().splitlines()
    except Exception as e:
        return {"error": str(e)}


