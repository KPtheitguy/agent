import requests
import socket

class AgentPortal:
    API_URL = "https://projectalphaapi.koushik.us/api/v1/agents"

    def __init__(self):
        self.agent_id = None

    def register_agent(self, registration_token, agent_name, version="1.0.0", heartbeat_interval=30, log_level="INFO"):
        """Register the agent with the provided details"""
        try:
            payload = {
                "registration_token": registration_token,
                "hostname": socket.gethostname(),
                "ip_address": socket.gethostbyname(socket.gethostname()),
                "agent_name": agent_name,
                "version": version,
                "heartbeat_interval": heartbeat_interval,
                "log_level": log_level,
                "config": {}
            }
            response = requests.post(f"{self.API_URL}/register", json=payload)
            if response.status_code == 200:
                self.agent_id = response.json().get("id")
                print("Agent registered successfully. Agent ID:", self.agent_id)
            else:
                print(f"Failed to register agent: {response.status_code}, {response.text}")
        except Exception as e:
            print(f"Error during agent registration: {str(e)}")
